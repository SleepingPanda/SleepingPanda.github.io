module.exports = {
  desc: 'Does math',
  usage: 'c <expression>',
  commands: ['c','calc','math'],
  main: function(from, to, text, mes, com) {
    var out = (to == bot.config.nick) ? from : to
    var mathjs = require('mathjs')
		mathjs.config({matrix: 'Matrix'})
		var parser = mathjs.parser()
    try {
      bot.say(out, ('' + mathjs.format(parser.eval(text), {precision: 14, exponential: {lower:1e-5,upper:1e10}})).replace('undefined','\u000304Invalid input'))
    } catch(e) {
      bot.say(out, "\u000304Invalid input")
    }
  }
}
