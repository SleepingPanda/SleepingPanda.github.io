module.exports = {
  desc: 'Flips a coin',
  usage: 'flip',
  store: [
    "You thought we could be decent men in an indecent time. But you were wrong. The world is cruel, and the only morality in a cruel world is chance.",
    "Why was it me who was the only one who lost everything?",
    "Remember that name you all had for me when I was at Internal Affairs? What was it?",
    "You're the one pointing the gun, Harvey. So point it at the people responsible.",
    "Tell your boy it's going to be all right. Lie, like I lied."
  ],
  commands: ['flip'],
  main: function(from, to, text, mes, com) {
    var out = (to == bot.config.nick) ? from : to
    if (Math.random() < 0.02) {
      bot.say(out, store[Math.floor(Math.random()*store.length)])
    } else if (Math.random() < 0.5)  {
      bot.say(out, 'Heads')
    } else {
      bot.say(out, 'Tails')
    }
  }
}
