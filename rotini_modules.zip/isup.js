module.exports = {
  desc: 'Checks if a website is up',
  usage: 'isup url',
  commands: ['isup'],
  main: function(from, to, text, mes, com) {
    var out = (to == bot.config.nick) ? from : to
    var link = (text.indexOf('http') == 0) ? text : ('http://' + text)
    request({uri: link, timeout: 10000}, function(err, res, body) {
      bot.say(out, '\u000307'+link.split(/https?:\/\//).join('') + '\u000f looks ' + ((body||(!err))?'\u000303fine':'\u000304down') + '\u000f from here')
    })
  }
}
