module.exports = {
  desc: 'Slaps people',
  usage: 'slap john',
  commands: ['slap'],
  main: function(from, to, text, mes, com) {
    if (to == bot.config.nick) { return }
    text = text.replace(/ /g,'')
    if (text && text != bot.config.nick) {
      bot.whois(text, function(info) {
        if (info.user) {
          bot.action(to, "slaps " + info.nick)
        }
      })
    } else {
      bot.action(to, "slaps " + from)
    }
  }
}
