module.exports = {
	desc: 'Allows users to silently sign off and have people attempting to communicate with them be informed of this',
	usage: 'away [reason]',
	store: {},
  commands: ['away'],
  load: function(s) {
    if (s) this.store = s
  },
  unload: function() {
    return this.store
  },
	main: function(from, to, text, mes, com) {
    this.store[from.toLowerCase()] = text	
	  console.log(from + ' has gone away [' + text + ']')
  },
  line: function(from, to, text, mes) {
    if (from.toLowerCase() in this.store) {
      delete this.store[from.toLowerCase()]
      console.log(from + ' has come back')
    }
    if (this.store[text.split(' ')[0].replace(/[:,]/, '').toLowerCase()] != undefined) {
      var out = (to == bot.config.nick) ? from : to
      var target = text.split(' ')[0].replace(/[:,]/, '')
      bot.say(out, target + ' is currently away' + (this.store[target.toLowerCase()]?' [\u000310'+this.store[target.toLowerCase()]+'\u000f]':''))
      console.log(from + ' attempted to contact ' + text.split(' ')[0].replace(':', ''))
    }
  }
}
