module.exports = {
  line: function(from, to, text, mes) {
    var uri = (text.match(/https?:\/\/(i.4cdn|is.4chan).org\/.{1,3}\/\S*/)||[])[0]
    if (uri) {
      uri = url.parse(uri).path.split('/').slice(1)
      request('http://a.4cdn.org/'+uri[0]+'/threads.json', function(e, r, body) {
        var catalog = JSON.parse(body).reduce(function(a,b,c){return a.concat(b.threads)},[])
        catalog.forEach(function(cur, i, a) {
          request('http://a.4cdn.org/'+uri[0]+'/thread/'+cur.no+'.json', function(e, r, body) {
            if (body && body.search('"tim":'+uri[1].split('.')[0]) != -1) {
              var out = (to == bot.config.name) ? from : to
              var post = body.slice(body.search(new RegExp('"no":[^{}]*"tim":'+uri[1].split('.')[0]))+5).match(/^[0-9]+/)[0]
              var name = body.slice(body.search(new RegExp('"filename":[^{}]*"tim":'+uri[1].split('.')[0]))+12).match(/[^"]+/)[0]
              name = name.replace(/&#[0-9]+;/g, a=>String.fromCharCode(parseInt(a.match(/[0-9]+/)[0])))
              bot.say(out, '(\u000307'+name+'.'+uri[1].split(".").slice(-1)[0]+'\u000f) \u000310https://boards.4chan.org/'+uri[0]+'/thread/'+cur.no+'#p'+post)
            }
          })
        })
      })
    }
  }
}
