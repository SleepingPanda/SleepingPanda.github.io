module.exports = {
  desc: 'Lets users leave reminders for themselves',
  usage: "remind 1d12h it's been a day and a half",
  store: {},

  load: function(_s) {
    if (_s) {
      this.store = _s
    } else {
      bot.check_db('remind', '{}')
      this.store.db = bot.read_db('remind', {})
      this.store.temp = []
    }
  },

  unload: function() {
    bot.write_db('remind', JSON.stringify(this.store.db))
    return this.store
  },

  commands: ['remind'],
  main: function(from, to, text, mes, com) {
    var out = (to == bot.config.nick) ? from : to
    var reminders = this.store.db
    var commands = text.split(' ')
    var htime = (commands[0].toLowerCase() == '-f') ? commands[1] : commands[0]
    var ptime = 0

    ptime += (htime.match(/[0-9.]*s/)||'0')[0].match(/[0-9.]*/)[0] * 1000
    ptime += (htime.match(/[0-9.]*m/)||'0')[0].match(/[0-9.]*/)[0] * 60000
    ptime += (htime.match(/[0-9.]*h/)||'0')[0].match(/[0-9.]*/)[0] * 3600000
    ptime += (htime.match(/[0-9.]*d/)||'0')[0].match(/[0-9.]*/)[0] * 86400000
    ptime += (htime.match(/[0-9.]*w/)||'0')[0].match(/[0-9.]*/)[0] * 604800000

    if (ptime > 2147483647 && commands[0].toLowerCase() == '-f') { bot.say(out, '\u000304Timeout too long for -f'); return }

    var time = Date.now() + ptime

    if (commands[0].toLowerCase() == '-f') {
      this.store.temp.push(setTimeout(function() {
        bot.say(out, from + ': \u000312' + commands.slice(2).join(' '))
      }, ptime))
    } else {
      if (reminders[from]) {
        reminders[from].push({t: time, m: commands.slice(1).join(' ')})
      } else {
         reminders[from] = [{t: time, m: commands.slice(1).join(' ')}]
      }
      bot.write_db('remind', JSON.stringify(reminders))
    }
  },

  line: function(from, to, text, mes) {
    var out = (to == bot.config.nick) ? from : to
    var reminders = this.store.db
    if (reminders[from]) {
      for (var i in reminders[from]) {
        if (reminders[from][i].t <= Date.now()) {
          bot.say(out, from + ": \u000312" + reminders[from][i].m)
          reminders[from].splice(i,1)
          bot.write_db('remind', JSON.stringify(reminders))
          i--
        }
      }
      if (reminders[from].length == 0) {
        delete reminders[from]
        bot.write_db('remind', JSON.stringify(reminders))
      }
    }
  }
}
