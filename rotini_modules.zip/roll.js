module.exports = {
  desc: 'Rolls dice',
  usage: 'roll 2d6',
  commands: ['roll'],
  main: function(from, to, text, mes, com) {
    var out = (to == bot.config.nick) ? from : to
    var dieType = 6
    if (text.match(/^[0-9]*d[0-9]*$/)) {
      dieType = text.split('d')[1];
    }
    if (dieType > 100) {
      dieType = 100
      bot.say(out, "Die size reduced to 100")
    }
    var dice = Math.floor(text.split('d')[0])||1
    if (dice > 256) {
      dice = 256
      bot.say(out, "Number of rolls reduced to 256")
    }
    var rolls = '',
        total = 0;
    for (i = 0; i < dice; i++) {
      var rand = (Math.floor((Math.random()*dieType)+1))
      rolls += (rand + " ")
      total += parseInt(rand)
    }
    bot.say(out, rolls)
    if (dice > 1) {
      bot.say(out, "Total: " + total);
    }
  }
}
