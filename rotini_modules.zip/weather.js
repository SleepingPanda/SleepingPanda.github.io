module.exports = {
  desc: 'Tells you the weather',
  usage: 'weather New York',
  store: {},
  load: function(_s) {
    if (_s) {
      this.store = _s
    } else {
      bot.check_db('weather', '{}')
      this.store.db = bot.read_db('weather', {})
    }
  },
  unload: function() {
    bot.write_db('weather', this.store.db)
    return this.store
  },
  commands: ['weather', 'forecast', 'fivecast'],
  main: function(from, to, text, mes, com) {
    var out = (to == bot.config.nick) ? from : to
    var weathAPI = 'http://api.openweathermap.org/data/2.5/'
    var locale = (text == (text = text.replace(/ ?-c ?/, ' '))) ? ['imperial','F','mph'] : ['metric','C','m/s']
    var days = text.match(/-[1-7]/) ? text.match(/-[1-7]/)[0].slice(1) : (com == 'fivecast' ? '5' : '3')
    text = text.replace(/ ?-[0-9]+ ?/, ' ')
    if (text.replace(' ','')) {
      this.store.db[from.toLowerCase()] = text.replace(' ','%20')
      bot.write_db('weather', JSON.stringify(this.store.db))
    }
    var loc = ((text).replace(' ','')?text.replace(' ','%20'):this.store.db[from.toLowerCase()])
    if (com == 'forecast' || com == 'fivecast') {
      request(weathAPI + 'forecast/daily?APPID=API_ID_GOES_HERE&cnt='+days+'&units='+locale[0]+'&q='+loc, function(e, r, body) {
        var weather = JSON.parse(body)
        if (weather.cod != 200) { bot.say(out, '\u000304API Error'); return }
        bot.say(out, 'Forecast for \u000310' + (weather.city.name) +'\u000f (\u000311' + weather.city.country + '\u000f)')
        weather.list.forEach(function(day, index) {
          bot.say(out, ((index==0)?'Now':(new Date(day.dt*1000).toString().slice(0,3))) + ': \u000304' + (day.temp.min.toFixed(1)||0) + '°'+locale[1]+'\u000f - \u000305'+ (day.temp.max.toFixed(1)||0) + '°'+locale[1] +' \u000307'+ day.humidity + '% humidity \u000311'+day.speed.toFixed(1) + locale[2]+' wind\u000f (\u000306' + day.weather[0].main + '\u000f)')
        })
      })
    } else {
      request(weathAPI + 'weather?APPID=API_ID_GOES_HERE&units='+locale[0]+'&q='+loc, function(e, r, body) {
        var weather = JSON.parse(body)
        if (weather.cod != 200) { bot.say(out, '\u000304API Error'); return }
        bot.say(out, from + ': [\u000310' + (weather.name) + '\u000f (\u000311' + weather.sys.country + '\u000f)] [\u000304' + (weather.main.temp||0) + '°'+locale[1]+'\u000f (\u000307' + (weather.main.humidity||0) + '% humidity\u000f)] [\u000311Wind: ' + weather.wind.speed + ' ' + locale[2] + ' at ' + weather.wind.deg + '°\u000f] [\u000306' + weather.weather[0].description.charAt(0).toUpperCase() + weather.weather[0].description.slice(1) + '\u000f]')
      })
    }
  }
}
