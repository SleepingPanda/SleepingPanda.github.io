module.exports = {
  commands: ['8ball'],
  desc: 'Shakes a magic 8-ball for you',
  usage: '8ball',
  main: (from, to, text, mes, comm) => {
    let out = (to==bot.config.nick) ? from : to
    const normal = ['Reply hazy. Try again later', 'No', 'Probably not', 'Never', 'Not a chance', 'Maybe someday', 'Maybe', 'Not any time soon', 'Perhaps soon', 'It\'s possible', 'Not likely', 'I\'m not sure', 'Could be', 'It might happen', 'Seems likely', 'Sure', 'The future looks bright', 'You might be surprised', 'I\'ll never tell', 'What do you think?', 'Do you really have to ask?', 'Eh', 'That would sure be something', 'Can\'t say for sure']
    const negative = ['Even those you hold dearest will never understand you on a deep level', 'Your words have no weight in the world', 'You will die alone', 'Nothing can escape the cold embrace of undoing', 'You make as much impact on the world as a ping pong ball on a brick wall', 'No one\'s life would be worse without you in it', 'No one is keeping tally of your feeble existence but you', 'All the world\'s a stage, and your loved ones are just actors', 'The problem is not the rest of the world; the problem is you', 'If you take a stand for your foolish beliefs, no one will stand behind you', 'You are wasting your life in the unfounded belief that your time accrues interest', 'You will hurt your foot', 'Every path you choose will lead to equal disappointment', 'Nothing will make up for the shameful things you have done', 'Criminals have a more positive effect on society than you', 'There is no escape', 'You have no influence over your future', 'You are not the exception', 'Every action you take may result in your death', 'Every path you choose will lead to equal disappointment', 'Your words have no weight in the world', 'They only laugh at your jokes out of pity', 'Your friends keep you around because it\'s amusing when you fail in your pursuits']
    bot.say(out, (Math.random()>0.1)?normal[Math.floor(Math.random()*normal.length)]:negative[Math.floor(Math.random()*negative.length)])
  }
}
